package com.hcl.eurekaclient;
import org.springframework.web.bind.annotation.*;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {

    @GetMapping("/hello")
    public String hello()
    {
        return "<h1>Hello World from Eureka Client</h1>";
    }
}