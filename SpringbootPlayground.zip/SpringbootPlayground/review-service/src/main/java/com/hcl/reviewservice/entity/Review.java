package com.hcl.reviewservice.entity;

    public class Review {
        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        String id;
        String author;
        String content;



        public String getAuthor() {
            return author;
        }

        public void setAuthor(String author) {
            this.author = author;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        @java.lang.Override
        public java.lang.String toString() {
            return "Review{" +
                    "id='" + id + '\'' +
                    ", author='" + author + '\'' +
                    ", content='" + content + '\'' +
                    '}';
        }
    }