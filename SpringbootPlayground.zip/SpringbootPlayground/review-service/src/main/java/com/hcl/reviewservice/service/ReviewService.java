package com.hcl.reviewservice.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;
import com.hcl.reviewservice.entity.Review;

@Service
public class ReviewService {
    private final RestTemplate restTemplate;

    public ReviewService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @Value("${api.key}")
    private String apiKey;

    public Review getReviewById(final String id)
    {

        final String url= String.format("https://api.themoviedb.org/3/review/%s?api_key=%s",id,apiKey);
        final Review review= restTemplate.getForObject(url, Review.class);
        return review;
    }



}
