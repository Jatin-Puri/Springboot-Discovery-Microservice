package com.hcl.reviewservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.hcl.reviewservice.service.ReviewService;
import java.util.List;
import com.hcl.reviewservice.entity.Review;



@RestController
public class ReviewController {


    @Autowired
    ReviewService reviewService;

    public ReviewController(ReviewService reviewService) {
        this.reviewService = reviewService;
    }

    @GetMapping("/api/reviewService/v1/review/{id}")
    public Review getReviewById(@PathVariable String id)
    {
        return reviewService.getReviewById(id);
        }

}

