If server not running
on server.port=8761
then
example if server is running on 8080
then we need to explicitly tell the client that server is not running in 8761
the add "eureka.client.serviceUrl.defaultZone=http://localhost:8080/eureka"
in the client's application.properties