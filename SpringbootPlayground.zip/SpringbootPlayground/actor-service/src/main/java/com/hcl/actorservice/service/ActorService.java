package com.hcl.actorservice.service;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.annotation.Autowired;
import com.hcl.actorservice.entity.Actor;
import com.hcl.actorservice.entity.ActorRoot;
import java.util.*;

@Service
public class ActorService{
   // @Autowired
    //private final Actor actor;

    public ActorService() {
    }

    private RestTemplate restTemplate=new RestTemplate();
    @Value("${api.key}")
    private String apiKey;

    public List<Actor> getAll(){
        //throw new MethodNotSupportedException("Get All not Supported");
        return null;
    }

    public Actor getOneById(final int id)
    {
        final String url= String.format("https://api.themoviedb.org/3/person/%d?api_key=%s",id,apiKey);
        final Actor actor = restTemplate.getForObject(url, Actor.class);
        return actor;    }


    public List<Actor> getActorsByMovieId(final int id){
        final String url= String.format("https://api.themoviedb.org/3/movie/%d/credits?api_key=%s",id,apiKey);
        final ActorRoot actorRoot = restTemplate.getForObject(url, ActorRoot.class);
        final List<Actor> actors = actorRoot.getActors();
        return actors;

    }


}