package com.hcl.actorservice.entity;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.hcl.actorservice.entity.Actor;
import java.util.*;

public class ActorRoot {
    @JsonProperty("id")
    private int movieId;
    @JsonProperty("cast")
    private List<Actor> actors;

    public int getMovieId() {
        return movieId;
    }

    public void setMovieId(int movieId) {
        this.movieId = movieId;
    }

    public List<Actor> getActors() {
        return actors;
    }

    public void setActors(List<Actor> actors) {
        this.actors = actors;
    }

    @java.lang.Override
    public java.lang.String toString() {
        return "ActorRoot{" +
                "movieId=" + movieId +
                ", actors=" + actors +
                '}';
    }
}

