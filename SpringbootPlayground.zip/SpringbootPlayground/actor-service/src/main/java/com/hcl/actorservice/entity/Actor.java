package com.hcl.actorservice.entity;
import com.fasterxml.jackson.annotation.JsonProperty;

 public class Actor {
    private int id;
    private String name;
    @JsonProperty("place_of_birth")
    private String placeOfBirth;
    private String gender;
    private float popularity;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPlaceOfBirth() {
        return placeOfBirth;
    }

    public void setPlaceOfBirth(String placeOfBirth) {
        this.placeOfBirth = placeOfBirth;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public float getPopularity() {
        return popularity;
    }

    public void setPopularity(float popularity) {
        this.popularity = popularity;
    }

     public Actor() {
     }

     public Actor(int id, String name, String placeOfBirth, String gender, float popularity) {
         this.id = id;
         this.name = name;
         this.placeOfBirth = placeOfBirth;
         this.gender = gender;
         this.popularity = popularity;
     }

     @java.lang.Override
    public java.lang.String toString() {
        return "Actor{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", placeOfBirth='" + placeOfBirth + '\'' +
                ", gender='" + gender + '\'' +
                ", popularity=" + popularity +
                '}';
    }
}