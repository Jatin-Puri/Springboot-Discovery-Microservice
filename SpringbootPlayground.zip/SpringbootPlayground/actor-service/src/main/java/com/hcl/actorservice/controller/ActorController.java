package com.hcl.actorservice.controller;

import com.hcl.actorservice.service.ActorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import com.hcl.actorservice.entity.Actor;

@RestController
@RequestMapping(path="/api/actorService/v1/actors")
public class ActorController{

    @Autowired
    public ActorController(ActorService actorService) {
        this.actorService = actorService;
    }

    @Autowired
    private final ActorService actorService;


    @GetMapping()
    public ResponseEntity<List<Actor>> getAll()
    {
        return ResponseEntity.ok(actorService.getAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Actor> getOneById(@PathVariable int id)
    {
        return ResponseEntity.ok(actorService.getOneById(id));
    }

    @GetMapping("/movies/{id}")
    public ResponseEntity<List<Actor>> getActorsByMovieId(@PathVariable int id)
    {
        return ResponseEntity.ok(actorService.getActorsByMovieId(id));
    }
}