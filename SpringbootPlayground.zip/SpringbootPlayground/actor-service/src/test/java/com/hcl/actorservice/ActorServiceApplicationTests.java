package com.hcl.actorservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ActorServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
