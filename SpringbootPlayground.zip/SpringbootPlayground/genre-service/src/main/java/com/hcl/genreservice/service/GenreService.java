package com.hcl.genreservice.service;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.annotation.Autowired;
import com.hcl.genreservice.entity.Genre;
import com.hcl.genreservice.entity.GenreRoot;
import java.util.List;

@Service
public class GenreService{

    public GenreService() {
    }


    private RestTemplate restTemplate=new RestTemplate();
    @Value("${api.key}")
    private String apiKey;
   // @Value("${api.key}")
   // private String apiKey;

    public List<Genre> getAllGenre(){
        //throw new MethodNotSupportedException("Get All not Supported");
        final String url= String.format("https://api.themoviedb.org/3/genre/movie/list?api_key=%s",apiKey);
        final GenreRoot genreRoot = restTemplate.getForObject(url, GenreRoot.class);
        final List<Genre> genres = genreRoot.getGenre();
        return genres;
    }



}