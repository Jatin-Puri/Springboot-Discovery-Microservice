package com.hcl.genreservice.entity;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.hcl.genreservice.entity.Genre;
import java.util.*;

public class GenreRoot {

    @JsonProperty("genres")
    private List<Genre> genre;

    public List<Genre> getGenre() {
        return genre;
    }

    public void setGenre(List<Genre> genre) {
        this.genre = genre;
    }

    @java.lang.Override
    public java.lang.String toString() {
        return "GenreRoot{" +
                "genre=" + genre +
                '}';
    }
}