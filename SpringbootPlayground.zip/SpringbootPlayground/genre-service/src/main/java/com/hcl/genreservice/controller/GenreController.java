package com.hcl.genreservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.hcl.genreservice.service.GenreService;
import java.util.List;
import com.hcl.genreservice.entity.Genre;



@RestController
@RequestMapping(path="/api/genreService/v1")
public class GenreController {


    @Autowired
    GenreService genreService;

    public GenreController(GenreService genreService) {
        this.genreService = genreService;
    }

    @GetMapping("/genre")
    public List<Genre> getAllGenre()
    {
        return genreService.getAllGenre();
    }

}

