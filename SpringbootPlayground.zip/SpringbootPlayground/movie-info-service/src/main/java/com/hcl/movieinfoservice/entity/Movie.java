package com.hcl.movieinfoservice.entity;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Movie {
    private int id;
    @JsonProperty("original_title")
    private String name;
    private String overview;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }

    @java.lang.Override
    public java.lang.String toString() {
        return "Movie{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", overview='" + overview + '\'' +
                '}';
    }
}