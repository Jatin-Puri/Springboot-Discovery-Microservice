package com.hcl.movieinfoservice.service;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.annotation.Autowired;
import com.hcl.movieinfoservice.entity.Movie;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@FeignClient(name="movie-info-client",url="https://api.themoviedb.org/3/movie")
public interface MovieInfoClient{
    // @RequestParam(value="api_key")
     //String apiKey="${api.key}";

    // @Autowired
    //private final Actor actor;

    @GetMapping("/{id}?api_key={apiKey}")
    Movie getMovieInfoById(@PathVariable int id,@RequestParam(value="api_key" ) String apiKey);



//    public MovieService() {
//    }
//
//    private RestTemplate restTemplate=new RestTemplate();

//    public Movie getOneById(final int id)
//    {
//        final String url= String.format("https://api.themoviedb.org/3/movie/{id}?api_key=%s",id,apiKey);
//        final Movie movie = restTemplate.getForObject(url, Movie.class);
//        return movie;
//    }
//

}