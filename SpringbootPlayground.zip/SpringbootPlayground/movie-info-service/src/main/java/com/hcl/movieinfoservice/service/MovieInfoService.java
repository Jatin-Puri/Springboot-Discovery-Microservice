package com.hcl.movieinfoservice.service;

import com.hcl.movieinfoservice.service.MovieInfoClient;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.annotation.Autowired;
import com.hcl.movieinfoservice.entity.Movie;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

@Service
public class MovieInfoService
{

    @Value("${api.key}")
    private String apiKey;
    private RestTemplate restTemplate=new RestTemplate();
    @Autowired
    private MovieInfoClient movieInfoClient;
    public Movie getMovieInfo(final int id)
    {
        final String url= String.format("https://api.themoviedb.org/3/movie/{id}?api_key=%s",id,apiKey);
        final Movie movieInfo = movieInfoClient.getMovieInfoById(id,apiKey);
        return movieInfo;

    }

}

