package com.hcl.movieinfoservice.controller;

import com.hcl.movieinfoservice.service.MovieInfoClient;
import com.hcl.movieinfoservice.service.MovieInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import com.hcl.movieinfoservice.entity.Movie;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path="/api/movieService/v1")
public class MovieInfoController {

//
//    @Autowired
//    private final MovieInfoService movieInfoService;


    public MovieInfoController(MovieInfoService movieInfoService) {
        this.movieInfoService = movieInfoService;
    }

    @Autowired
    private final MovieInfoService movieInfoService;


    @GetMapping("/{id}")
    public Movie getMovieInfo(@PathVariable int id) {
        return movieInfoService.getMovieInfo(id);

    }
}
