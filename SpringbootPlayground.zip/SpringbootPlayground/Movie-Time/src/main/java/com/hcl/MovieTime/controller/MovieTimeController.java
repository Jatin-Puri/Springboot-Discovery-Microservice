package com.hcl.MovieTime.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.web.client.RestTemplate;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;

@RestController
public class MovieTimeController {

    @Autowired
    private DiscoveryClient discoveryClient;
    @Autowired
    private LoadBalancerClient loadBalancerClient;

    public MovieTimeController(LoadBalancerClient loadBalancerClient) {
        this.loadBalancerClient = loadBalancerClient;
    }

    private RestTemplate restTemplate = new RestTemplate();

    @GetMapping("/cast")
    public String getOneByTitle(String title){
        //final List<ServiceInstance> actorservice = discoveryClient.getInstances("ACTORSERVICE");
        //final ServiceInstance actorServiceInstance = actorservice.get(0);
       // final String baseUrl = actorServiceInstance.getUri().toString();
       // String requestUrl= baseUrl+"/api/actorService/v1/actors/movies/238";
        //final String response= restTemplate.getForObject(requestUrl,String.class);


        final ServiceInstance actorServiceInstance = loadBalancerClient.choose("ACTORSERVICE");
        final String baseUrl = actorServiceInstance.getUri().toString();
        String requestUrl= baseUrl+"/api/actorService/v1/actors/movies/238";
        final String response= restTemplate.getForObject(requestUrl,String.class);
        return response;
    }
    @GetMapping("/review")
    public String getReviewById(String title){
        final List<ServiceInstance> reviewservice = discoveryClient.getInstances("REVIEWSERVICE");
        final ServiceInstance reviewServiceInstance = reviewservice.get(0);
         final String baseUrl = reviewServiceInstance.getUri().toString();
         String requestUrl= baseUrl+"/api/reviewService/v1/review/6599c8be0d11f20095b35052";
        final String response= restTemplate.getForObject(requestUrl,String.class);
        return response;
    }
    @GetMapping("/genres")
    public String getAllGenres(String title){

        final ServiceInstance genreServiceInstance = loadBalancerClient.choose("GENRESERVICE");
        final String baseUrl = genreServiceInstance.getUri().toString();
        String requestUrl= baseUrl+"/api/genreService/v1/genre";
        final String response= restTemplate.getForObject(requestUrl,String.class);
        return response;
    }

    @GetMapping("/info")
    public String getMovieInfoService(String title){

        final ServiceInstance movieInfoServiceInstance = loadBalancerClient.choose("MOVIEINFOSERVICE");
        final String baseUrl = movieInfoServiceInstance.getUri().toString();
        String requestUrl= baseUrl+"/api/movieService/v1/933131";
        final String response= restTemplate.getForObject(requestUrl,String.class);
        return response;
    }


}