package com.hcl.MovieTime;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieTimeApplicationTests {

	@Test
	void contextLoads() {
	}

}
