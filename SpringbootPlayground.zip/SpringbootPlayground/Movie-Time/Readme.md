This is a microservice project using Netflix Eureka

**IntelliJ Run Configuration**
Edit Configuration->select working directory
and in Run add "spring-boot:run"

**POM Configurations**
Spring Web
eureka server and client



**TMDB API**
we need to talk to "https://www.themoviedb.org"
which has its API in location "https://developer.themoviedb.org/reference/intro/getting-started"
getting api key "https://www.themoviedb.org/settings/api/request"

Api key : 633f84da9d8950e3c88cb8baeaaa1156

**EurekaServerServices**
Main app -movieapp
-> title - id
-> MovieDetailsEntity contains movie info, reviews, actor, genre

ActorService-> actor-id
-> all actors
-> by movie id
GenreService-> id
-> get all
ReviewService-> id
-> movie id
->all not supported
MovieInfoService-> id
->all not supported


To create more than one instance of a app
mvn spring-boot:run -D spring-boot.run.jvmArguments='-Dserver.port=8081'
change port number any available